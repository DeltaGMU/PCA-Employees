# PCA Web Interface
This repository contains the source code for Team Delta's PCA VueJS Web Interface Server.
This is an integral part of the front-end architecture and will be used to provide functionalities including employee timesheets, employee leave requests, student before-care and after-care check-in/check-out systems, and administrative functions by interacting with the REST API provided by the Python Processing Server.
